package tn.esprit.examen.Smartmeet.entities.SalmaBenRomdhan;

public enum TypeFollowUpStatus {
    EEEE,RRRR;
}
