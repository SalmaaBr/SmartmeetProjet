package tn.esprit.examen.Smartmeet.entities.GhanemRidene;

public enum TypeSponsorshipMaterial {
    CHAIR,LAPTOP,MICROPHONE,WHITEBOARD,PROJECTOR


}
