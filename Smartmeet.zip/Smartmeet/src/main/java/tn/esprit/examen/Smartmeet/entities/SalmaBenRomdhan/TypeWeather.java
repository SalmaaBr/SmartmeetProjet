package tn.esprit.examen.Smartmeet.entities.SalmaBenRomdhan;

public enum TypeWeather {
    SUNNY, RAINY, CLOUDY
}
