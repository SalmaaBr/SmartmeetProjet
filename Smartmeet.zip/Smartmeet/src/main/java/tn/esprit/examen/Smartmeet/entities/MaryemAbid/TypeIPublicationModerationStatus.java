package tn.esprit.examen.Smartmeet.entities.MaryemAbid;

public enum TypeIPublicationModerationStatus {
    PENDING,APPROVED,REJECTED

}
