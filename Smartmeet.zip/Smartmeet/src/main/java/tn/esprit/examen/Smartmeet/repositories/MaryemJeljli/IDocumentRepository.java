package tn.esprit.examen.Smartmeet.repositories.MaryemJeljli;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.esprit.examen.Smartmeet.entities.MaryemJeljli.Document;

public interface IDocumentRepository extends JpaRepository<Document, Integer> {
}
