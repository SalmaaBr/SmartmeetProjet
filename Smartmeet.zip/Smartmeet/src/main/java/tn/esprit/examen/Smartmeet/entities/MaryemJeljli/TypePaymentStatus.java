package tn.esprit.examen.Smartmeet.entities.MaryemJeljli;

public enum TypePaymentStatus {
    PENDING,COMPLETED,FAILED
}
