package tn.esprit.examen.Smartmeet.repositories.MaryemJeljli;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.esprit.examen.Smartmeet.entities.MaryemJeljli.Participation;

public interface IParticipationRepository extends JpaRepository<Participation, Integer> {
}
