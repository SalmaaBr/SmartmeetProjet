package tn.esprit.examen.Smartmeet.entities.MaryemSalhi;

public enum TypeFeeling {
    POSITIVE, NEUTRAL, NEGATIVE
}
