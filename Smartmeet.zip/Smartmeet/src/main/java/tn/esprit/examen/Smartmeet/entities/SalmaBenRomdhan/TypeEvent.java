package tn.esprit.examen.Smartmeet.entities.SalmaBenRomdhan;

public enum TypeEvent {
    CONCERT, SPORT, CONFERENCE
}
