package tn.esprit.examen.Smartmeet.entities.GhanemRidene;

public enum TypeFoundObjectStatus {
    AVAILABLE,CLAIMED,UNDER_VERIFICATION,RETURNED
}
