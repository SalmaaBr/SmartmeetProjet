package tn.esprit.examen.Smartmeet.repositories.YousraFourati;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.esprit.examen.Smartmeet.entities.YousraFourati.Session;

public interface ISessionRepository extends JpaRepository<Session, Integer> {
}
