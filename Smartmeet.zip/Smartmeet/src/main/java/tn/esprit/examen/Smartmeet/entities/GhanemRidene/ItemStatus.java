package tn.esprit.examen.Smartmeet.entities.GhanemRidene;

public enum ItemStatus {
    AVAILABLE, CLAIMED, RETURNED
}