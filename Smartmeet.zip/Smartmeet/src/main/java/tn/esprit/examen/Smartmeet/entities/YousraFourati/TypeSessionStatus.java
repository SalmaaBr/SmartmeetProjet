package tn.esprit.examen.Smartmeet.entities.YousraFourati;

public enum TypeSessionStatus {
    SCHEDULED,ONGOING,CANCELED,FINISHED

}
