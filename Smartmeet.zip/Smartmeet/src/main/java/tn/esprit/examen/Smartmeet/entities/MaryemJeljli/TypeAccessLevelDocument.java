package tn.esprit.examen.Smartmeet.entities.MaryemJeljli;

public enum TypeAccessLevelDocument {
    READ,WRITE

}
