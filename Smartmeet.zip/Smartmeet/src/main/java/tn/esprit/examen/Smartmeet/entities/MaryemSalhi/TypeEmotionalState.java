package tn.esprit.examen.Smartmeet.entities.MaryemSalhi;

public enum TypeEmotionalState {
    HAPPY, SAD, STRESSED, RELAXED, NEUTRAL
}
