package tn.esprit.examen.Smartmeet.repositories.MaryemSalhi;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.esprit.examen.Smartmeet.entities.MaryemSalhi.Feedback;

public interface IFeedbackRepository extends JpaRepository<Feedback, Integer> {
}
