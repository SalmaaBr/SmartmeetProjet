package tn.esprit.examen.Smartmeet.entities.GhanemRidene;

public enum SponsorLevel {
    OR, ARGENT, BRONZE
}