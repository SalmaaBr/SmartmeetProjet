package tn.esprit.examen.Smartmeet.entities.GhanemRidene;

public enum ClaimStatus {
    PENDING, APPROVED, REJECTED

}