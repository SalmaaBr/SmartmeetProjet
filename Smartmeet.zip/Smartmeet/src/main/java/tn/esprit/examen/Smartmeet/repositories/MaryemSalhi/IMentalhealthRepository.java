package tn.esprit.examen.Smartmeet.repositories.MaryemSalhi;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.esprit.examen.Smartmeet.entities.MaryemSalhi.MentalHealth;

public interface IMentalhealthRepository extends JpaRepository<MentalHealth, Integer> {
}
