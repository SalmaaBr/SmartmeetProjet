package tn.esprit.examen.Smartmeet.repositories.YousraFourati;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.esprit.examen.Smartmeet.entities.YousraFourati.SmartMeeting;

public interface ISmartMeetingRepository extends JpaRepository<SmartMeeting, Integer> {
}
