package tn.esprit.examen.Smartmeet.entities.MaryemAbid;

public enum TypeResourceStatus {
    AVAILABLE,RESERVED,BROKEN,UNDER_MAINTENANCE

}
