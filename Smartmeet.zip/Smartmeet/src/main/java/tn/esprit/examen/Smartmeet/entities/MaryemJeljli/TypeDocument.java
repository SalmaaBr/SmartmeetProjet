package tn.esprit.examen.Smartmeet.entities.MaryemJeljli;

public enum TypeDocument {
    ARTICLE,VIDEO,PHOTO,PRESENTATION,REPORT,RESEARCH_PAPER,CASE_STUDY,EBOOK,TUTORIAL,THESIS

}
