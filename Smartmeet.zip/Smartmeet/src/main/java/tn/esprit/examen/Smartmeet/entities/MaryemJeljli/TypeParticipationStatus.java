package tn.esprit.examen.Smartmeet.entities.MaryemJeljli;

public enum TypeParticipationStatus {
    ATTENDING,NOT_ATTENDING,WAITLISTED

}
