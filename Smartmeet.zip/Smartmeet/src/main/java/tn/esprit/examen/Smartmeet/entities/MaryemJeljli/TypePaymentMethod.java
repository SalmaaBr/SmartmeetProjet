package tn.esprit.examen.Smartmeet.entities.MaryemJeljli;

public enum TypePaymentMethod {
    CREDIT_CARD,STRIPE,PAYPAL
}
