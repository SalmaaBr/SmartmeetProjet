package tn.esprit.examen.Smartmeet.entities.MaryemAbid;

public enum TypeIPublicationStatus {
    PUBLISHED,DRAFT,MODERATED,ARCHIVED

}
