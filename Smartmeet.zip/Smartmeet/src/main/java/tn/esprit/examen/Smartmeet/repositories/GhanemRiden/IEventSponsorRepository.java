package tn.esprit.examen.Smartmeet.repositories.GhanemRiden;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.esprit.examen.Smartmeet.entities.GhanemRidene.EventSponsor;

public interface IEventSponsorRepository extends JpaRepository<EventSponsor, Long> {
}
