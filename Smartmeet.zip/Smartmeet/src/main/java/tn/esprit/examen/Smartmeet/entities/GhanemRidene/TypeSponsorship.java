package tn.esprit.examen.Smartmeet.entities.GhanemRidene;

public enum TypeSponsorship {
    MONETARY,MATERIAL

}
