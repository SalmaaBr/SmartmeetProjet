package tn.esprit.examen.Smartmeet.entities.Users;

public enum TypeUserRole {
    USER,ADMIN,PARTICIPANT,SPEAKER,TRAINER,SPONSOR,COMPANY
}
