package tn.esprit.examen.Smartmeet.repositories.MaryemAbid;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.esprit.examen.Smartmeet.entities.MaryemAbid.InteractivePublication;

public interface IInteractivePublicationRepository extends JpaRepository<InteractivePublication, Integer> {
}
