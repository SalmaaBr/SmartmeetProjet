package tn.esprit.examen.Smartmeet.entities.MaryemJeljli;

public enum TypeDocumentVisibility {
    PUBLIC,PRIVATE

}
