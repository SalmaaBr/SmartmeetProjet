package tn.esprit.examen.Smartmeet.entities.MaryemJeljli;

public enum TypeWeather {
    SUNNY, CLOUDY, RAINY, SNOWY, WINDY, FOGGY, STORMY, HAIL, THUNDERSTORM, DRIZZLE
}
