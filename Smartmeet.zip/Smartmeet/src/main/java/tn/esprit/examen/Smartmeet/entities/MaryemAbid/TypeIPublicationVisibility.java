package tn.esprit.examen.Smartmeet.entities.MaryemAbid;

public enum TypeIPublicationVisibility {
    PUBLIC,PRIVATE,RESTRICTED

}
