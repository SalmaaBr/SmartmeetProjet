package tn.esprit.examen.Smartmeet.entities.MaryemAbid;

public enum TypeResource {
    ROOM,CHAIR,LAPTOP,MICROPHONE,WHITEBOARD,PROJECTOR

}
